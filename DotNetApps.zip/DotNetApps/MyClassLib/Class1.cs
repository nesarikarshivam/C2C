﻿namespace MyClassLib;

public class Class1
{

}

﻿// See https://aka.ms/new-console-template for more information


using System;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.InteropServices;

partial class Program

{
    delegate void Compute(int n1, int n2);

    delegate void Contractor(double budget);

    static void Main()
    {

    }
        
        static void UsingGenericDelegates()
        {
            Action<double> RockyRaniRegisterMarriage = new Action<double>
                ((budget) =>
                {
                    Console.WriteLine($"registratoin fees: {budget * 95 / 100}");
                    Console.WriteLine($"Reception charges: {budget * 5 / 100}");
                }
                );
            Func<int, int, string> modifiedCompute = (n1, n2) => $"Addition: {n1 + n2}";
            modifiedCompute += (n1, n2) => $"Subrattion:{n1 - n2}";

            Predicate<int> isActive = (v) =>
            {
                if (v == 0) return false;
                else return true;
            };

            //Invoke all above delegates
            RockyRaniRegisterMarriage(50000d);
            Console.WriteLine(modifiedCompute(100, 200));
            Console.WriteLine($"output of predicate: {isActive(1)}");
        }
    
    private static void RockyRaniMarriageDelegate()
    {
        Contractor RockyRaniMarriage = new Contractor((b) => Console.WriteLine($"PAndit charges: {b * 20 / 100}"));
        RockyRaniMarriage += (b) => Console.WriteLine($"CAtering Charges: {b * 50 / 100}");
        RockyRaniMarriage += (b) => Console.WriteLine($"Mandap Decoration: {b * 5 / 100}");
        RockyRaniMarriage += (b) => Console.WriteLine($"Couple arrive in Porsche reserved for 2 days: {b * 15 / 100}");

        RockyRaniMarriage(5000000);
    }
    private static void UsingLamdas()
    {
        Compute ObjShortCompute = new Compute((a, b) => Console.WriteLine($"Addition : {a + b}"));
        ObjShortCompute += (s, t) => Console.WriteLine($"Subtraction {s - t}");
        ObjShortCompute += (a, b) => Console.WriteLine($"Subtraction {a - b}");
        ObjShortCompute += (s, t) => Console.WriteLine($"Subtraction {s - t}");

        ObjShortCompute(250, -50);
    }
    private static void DelegatesUsingLongCutTechnique()
    {
        Compute objCompute = new Compute(AddFn);
        objCompute += SubFn;
        objCompute += MulFn;
        objCompute += DivFn;

        //invoke the delegate exactly like function
        objCompute(100, 200);
    }

    static void AddFn(int n1, int n2)
    {
        Console.WriteLine($"Output of addition is going to be {n1 + n2}");
    }
    static void SubFn(int n1, int n2)
    {
        Console.WriteLine($"Output of addition is going to be {n1 - n2}");
    }
    static void MulFn(int n1, int n2)
    {
        Console.WriteLine($"Output of addition is going to be {n1 * n2}");
    }
    static void DivFn(int n1, int n2)
    {
        Console.WriteLine($"Output of addition is going to be {n1 / n2}");
    }
}




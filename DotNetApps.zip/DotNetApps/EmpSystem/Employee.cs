﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpSystem
{
    
    public class Employee : Person, IEmployeeContract

    {

        public event EventHandler Join;
        public Employee() : base()
        {
            this.ViewContract();
            this.Sign();
            this.EmpId = new Random(1000).Next();
            Emputils.EmpCount++;
        }

        public Employee(string pAadhar): this()
        {
            this.Aadhar = pAadhar;
        }
        private bool _contractSigned = false;
        private bool _hasReadContract = false;

        public Employee(string pAadhar, string pMobile) : base(pAadhar, pMobile)
        {
            this.ViewContract();
            this.Sign();
            this.EmpId = new Random(1000).Next();
            Emputils.EmpCount++;
        }
        private int _empId;
        public int EmpId { get { return _empId; } private set { _empId = value; } }
        
     public string Designation {  get; set; }
     public double Salary { get; set; }
     public DateTime DOJ {  get; set; }
     public bool IsActive {  get; set; }
        public string AttendTraining(String pTraining)
        {
            return $"{this.Name} attended a training {pTraining}";
        }

     public string FillTimesheet(List<string> ptasks) {
            var csvTask = "";
            foreach (var task in ptasks)
            {
                csvTask = $"{csvTask} ,{task}";
            }
            return $"{this.Name} has worked on {csvTask} on {DateTime.Now.ToShortDateString()}";
        }

        public override string Work()
        {
            return $"{this.Name} with {this.EmpId} works for 8hrs a day at KPMG";
        }
        public void Sign()
        {
            _contractSigned = true;
        }

    public void ViewContract()
        {
            _hasReadContract = true;
        }

    public void SetTaxInfo(string ptaxInfo)
        {
            this.TaxDetails = ptaxInfo;
        }

    public string GetTaxInfo()
        {
            return $"{this.Name}: your tax details are: {this.TaxDetails}";
        }
    }
}

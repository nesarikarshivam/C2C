﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpSystem
{
    public class Father1: Talents
    {
        public virtual string Settle()
        {
            return "Get a goverment job, retire by 60yrs and settle in native";
        }

        public string GetMarried()
        {
            return "Match horoscope, marry person from same religion, caste, settle in family";
        }

        public override string Drawing()
        {
            return "Drawing portraits";

        }

        public override string WhatIsdating()
        {
            return "Meeting special friend at resturant";
        }
    }

    public class Child : Father1
    {
        public override string Settle()
        {
            string howToLive = "Get a fat salary job in fortune 500 company, visit different countries , live outside hometown";
            howToLive = $"{howToLive} and later follow this: {base.Settle()}";
            return howToLive;
        }

        new public string GetMarried()
        {
            return "register marriage, surprise parents and settle abroad";
        }

    }

    public abstract class Talents
    {
        public abstract string WhatIsdating();
        public abstract string Drawing();

    }

}

﻿// See https://aka.ms/new-console-template for more information
using EmpSystem;

Person Rohit =  new Person();
Rohit.Name = "Rohit";
Console.WriteLine(Rohit.Eat());

Person Lekha = new Person();
Lekha.Name = "Lekha";
Console.WriteLine(Lekha.Work());



Person Rushabh = new Employee() { Designation="Intern", DOJ= DateTime.Now.AddMonths(-1) };
Rushabh.Name = "Rushabh";
((Employee)Rushabh).Designation = "Analyst";
Console.WriteLine(Rushabh.Work());
Console.WriteLine($"EmpId for {Rushabh.Name} is {((Employee)Rushabh).EmpId}");  

Console.WriteLine(((Employee)Rushabh).AttendTraining("C2C"));

Father1 SharmaJiisFather1 = new Father1();
Console.WriteLine($"sharmaji father : {SharmaJiisFather1.Settle()}");
Console.WriteLine($"sharmaji gets earrned: {SharmaJiisFather1.GetMarried()}");

Father1 SharmaJi = new Child();
Console.WriteLine($"sharmaji: {SharmaJi.Settle()}");
Console.WriteLine($"sharmaji gets earrned: {SharmaJi.GetMarried()}");
Console.WriteLine($"sharmaji concept of drawing (Using Abstract): {SharmaJi.Drawing()}");
Console.WriteLine($"sharmaji concept of d (Using Abstract): {SharmaJi.WhatIsdating()}");

Father1 SharmaJiV2 = new Child();
Console.WriteLine($"sharmaji V2 gets married: {((Child)SharmaJiV2).GetMarried()}");

Employee Vidhyasagar = new Employee();
Vidhyasagar.Name = "Vidhyasagar";
Vidhyasagar.Designation = "Security System Analyst";
Console.WriteLine(Vidhyasagar.Work());


Employee Srikar = new Employee();
Srikar.SetTaxInfo("I'm eliglible in the 20% tax payer category");
Console.WriteLine(Srikar.GetTaxInfo());

Person Sricharan = new Person("468149184846" , "+91 8147356032");
Console.WriteLine($"Aadhar : {Sricharan.Aadhar} | Mobile Number: {Sricharan.MobileNumber}");

Console.WriteLine($"total count :{Emputils.EmpCount}");

//Adding Employees to a temporary db - using static List<Employee>
Emputils.EmpDb.Add(Srikar);
Emputils.EmpDb.Add(Vidhyasagar);
Emputils.EmpDb.Add(new Employee("1232267809876543", "+91 9242160696") { Name="Nidha", Designation="Analyst", Salary=60000});
Emputils.EmpDb.Add(new Employee("1234567709876543", "+91 9242180898") { Name = "keerthi", Designation = "Analyst", Salary = 60000 });
Emputils.EmpDb.Add(new Employee("1234567809006543", "+91 9242170797") { Name = "Mahesh", Designation = "Sr Analyst", Salary = 90000 });

//get all employees whose aadhar card starts with 12

var resultList = Emputils.EmpDb.Where((emp) => emp.Aadhar != null && emp.Aadhar.StartsWith("12")); 
resultList.ToList().ForEach((emp) =>Console.WriteLine($"{emp.Name} | {emp.Aadhar}" ));

//get all employes whose salary is greater than 6 lakh

var resultList1 = Emputils.EmpDb.Where((emp) => emp.Salary != null && (emp.Salary) > 60000);
resultList1.ToList().ForEach((emp) => Console.WriteLine($"{emp.Name} | {emp.Salary}")); 

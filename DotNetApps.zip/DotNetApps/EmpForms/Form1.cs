using EmpSystem;

namespace EmpForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button1.Click += Button1_Click2;
            button1.Click += Button1_Click3;
            Employee Srikar =  new Employee();
            Srikar.Join += Srikar_Join; ;

        }

        private void Button_Click3(object? sender, EventArgs e)
        {
            MessageBox.Show("Srikar joined KPMG");
        }

      
        private void Button1_Click2(object? sender, EventArgs e)
        {
            MessageBox.Show("I Am Subscriber one");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("I Am Subscriber one");
        }
    }
}